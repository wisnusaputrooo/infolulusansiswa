                        <!-- Footer -->
                        <footer class="footer d-print-none">
                            <div class="row align-items-center justify-content-xl-between">
                                <div class="col-xl-6">
                                    <div class="copyright text-center text-xl-left text-muted text-black">
                                        <p class="text-sm text-indigo font-weight-500">Copyright {{now()->year}} © Wisnu Saputro - Konsepsederhana.id</p>
                                    </div>
                                </div>
                                <div class="col-xl-6">
                                    <p class="float-right text-sm font-weight-500"><a class="text-indigo" href="https://smkharapankts.sch.id" target="_blank">SMK Harapan Kartasura</a></p>
                                </div>
                            </div>
                        </footer>
                        <!-- Footer -->
