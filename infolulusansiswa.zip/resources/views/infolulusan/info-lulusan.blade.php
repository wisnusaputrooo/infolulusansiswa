@extends('layouts.main')

@section('TitlePage', 'Sistem Informasi Kelulusan')


@section('pages')
                        <!-- Page content -->
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-12">
                                @include('layouts.message-alert')
                                    <div class="card-box card shadow">
                                        <div class="card-body border-bottom">
                                            <h3 class=" mb-0">Data Lulusan Siswa tahun 2020/2021</h3>
                                        </div>
                                        <div class="card-body">
                                            <div class="mb-0">
                                                <table class="table table-striped table-bordered w-100 text-nowrap dataTable no-footer">
                                                    <thead>
                                                        <tr class="text-center">
                                                            <th>No</th>
                                                            <th>Nama</th>
                                                            <th>Kelas</th>
                                                            <th>NISN</th>
                                                            <th>Tanggal Lahir</th>
                                                            <th>Total Login</th>
                                                            <th>Status Kelulusan</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $no = 1?>
                                                        @foreach ($users as $user)
                                                        <tr>
                                                            <td>{{$no++}}</td>
                                                            <td>{{$user->nama}}</td>
                                                            <td>{{$user->kelas}}</td>
                                                            <td>{{$user->nisn}}</td>
                                                            <td class="text-center">{{$user->tanggal_lahir}}</td>
                                                            <td>{{$user->jumlah_akses}}</td>
                                                            <td class="text-center">
                                                                    {!!($user->is_pass) ? '<span class="badge  badge-lg badge-default">Lulus</span>':'<span class="badge  badge-lg badge-warning">Dipending</span>'!!}
                                                            </td>
                                                        </tr> 
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end row -->
                        
                            @include('layouts.footer')
                        
                        </div>
    
@endsection

@push('javacriptsContent')
    
@endpush